package br.sc.catolica.fastfood.model;

public enum TipoPagamento {
    
    CRÉDITO, DÉBITO;
  
}
